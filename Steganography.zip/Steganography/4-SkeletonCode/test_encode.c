#include<stdio.h>
#include<string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc, char **argv)
{
    OperationType operation;

    if (argc < 2)
    {
        fprintf(stderr, "Usage: %s -e <source.bmp> <secret.txt> [stego.bmp]\n"
                        "       %s -d <stego.bmp> [output_file]\n",
                argv[0], argv[0]);
        return e_failure;
    }

    operation = check_operation_type(argv);
    if(operation == e_encode)
    {
        if (argc < 4 || argc > 5)
        {
            fprintf(stderr, "Usage: %s -e <source.bmp> <secret.txt> [stego.bmp]\n", argv[0]);
            return e_failure;
        }
        printf("Encoding is chosen\n");
        EncodeInfo encInfo;
    
        if(read_and_validate_encode_args(argv, &encInfo) == e_success)
        {
            printf("Read and Validate successful\n");

        }
        else
        {
            printf("Read and validate unsucessful\n");
            return e_failure;
        } 
    }
    else if(operation == e_decode)
    {
        DecodeInfo decInfo;
        if (read_and_validate_decode_args(argc, argv, &decInfo) == e_failure)
        {
            return e_failure;
        }
        if (do_decoding(&decInfo) == e_failure)
        {
            return e_failure;
        }
    }
    else
    {
        printf("Unsupported,Pass correct arguement\n");
        return e_failure;
    }
    return e_success;

}

OperationType check_operation_type(char *argv[])
{
    if(strcmp (argv[1], "-e")==0)
        return e_encode;
    else if(strcmp (argv[1],"-d") == 0)
        return e_decode;
    else
        return e_unsupported;
}


