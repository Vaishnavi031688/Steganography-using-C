#ifndef DECODE_H
#define DECODE_H

#include <stdio.h>
#include "types.h"

#define DECODE_EXTENSION_SIZE 4

typedef struct _DecodeInfo
{
    char *stego_image_fname;
    char *output_fname;
    FILE *fptr_stego_image;
    char extn_secret_file[DECODE_EXTENSION_SIZE + 1];
    uint secret_file_size;
} DecodeInfo;

Status read_and_validate_decode_args(int argc, char *argv[], DecodeInfo *decInfo);
Status do_decoding(DecodeInfo *decInfo);

#endif
