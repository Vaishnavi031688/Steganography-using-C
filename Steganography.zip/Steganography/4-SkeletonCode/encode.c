﻿#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "common.h"
#include "encode.h"
#include "types.h"

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    if (argv == NULL || encInfo == NULL)
    {
        return e_failure;
    }

    if (argv[2] == NULL || strstr(argv[2], ".bmp") == NULL)
    {
        printf("Source file is incorrect\n");
        return e_failure;
    }
    encInfo->src_image_fname = argv[2];

    if (argv[3] == NULL || strstr(argv[3], ".txt") == NULL)
    {
        printf("Secret file is incorrect\n");
        return e_failure;
    }
    encInfo->secret_fname = argv[3];

    if (argv[4] != NULL && strstr(argv[4], ".bmp") != NULL)
    {
        printf("Stego file is correct\n");
        encInfo->stego_image_fname = argv[4];
    }
    else
    {
        encInfo->stego_image_fname = "stego.bmp";
    }

    return e_success;
}

Status open_files(EncodeInfo *encInfo)
{
    if (encInfo == NULL)
    {
        return e_failure;
    }

    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");
    if (encInfo->fptr_src_image == NULL)
    {
        perror(encInfo->src_image_fname);
        return e_failure;
    }

    encInfo->fptr_secret = fopen(encInfo->secret_fname, "rb");
    if (encInfo->fptr_secret == NULL)
    {
        perror(encInfo->secret_fname);
        fclose(encInfo->fptr_src_image);
        encInfo->fptr_src_image = NULL;
        return e_failure;
    }

    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "wb");
    if (encInfo->fptr_stego_image == NULL)
    {
        perror(encInfo->stego_image_fname);
        fclose(encInfo->fptr_secret);
        encInfo->fptr_secret = NULL;
        fclose(encInfo->fptr_src_image);
        encInfo->fptr_src_image = NULL;
        return e_failure;
    }

    return e_success;
}

uint get_image_size_for_bmp(FILE *fptr_image)
{
    unsigned char header[8];
    uint width = 0;
    uint height = 0;

    if (fptr_image == NULL)
    {
        return 0;
    }

    if (fseek(fptr_image, 18, SEEK_SET) != 0)
    {
        return 0;
    }

    if (fread(header, 1, sizeof(header), fptr_image) != sizeof(header))
    {
        return 0;
    }

    width = (uint)header[0] | ((uint)header[1] << 8) | ((uint)header[2] << 16) | ((uint)header[3] << 24);
    height = (uint)header[4] | ((uint)header[5] << 8) | ((uint)header[6] << 16) | ((uint)header[7] << 24);

    return width * height * 3;
}

uint get_file_size(FILE *fptr)
{
    long size;

    if (fptr == NULL)
    {
        return 0;
    }

    if (fseek(fptr, 0, SEEK_END) != 0)
    {
        return 0;
    }

    size = ftell(fptr);
    if (size < 0)
    {
        return 0;
    }

    rewind(fptr);
    return (uint)size;
}

Status check_capacity(EncodeInfo *encInfo)
{
    uint required_bits;
    uint required_bytes;

    if (encInfo == NULL)
    {
        return e_failure;
    }

    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);
    required_bytes = (uint)(strlen(MAGIC_STRING) + MAX_FILE_SUFFIX + sizeof(uint) + encInfo->size_secret_file);
    required_bits = required_bytes * 8;

    if (encInfo->image_capacity < required_bits)
    {
        fprintf(stderr, "Image capacity is too small for the secret file. Required bits: %u, available bits: %u\n",
                required_bits, encInfo->image_capacity);
        return e_failure;
    }

    return e_success;
}

Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    unsigned char bmp_header[14];
    unsigned char buffer[4096];
    uint32_t pixel_offset;
    size_t bytes_to_copy;
    long remaining;
    size_t bytes_read;

    if (fptr_src_image == NULL || fptr_dest_image == NULL)
    {
        return e_failure;
    }

    if (fseek(fptr_src_image, 0, SEEK_SET) != 0)
    {
        return e_failure;
    }

    if (fread(bmp_header, 1, sizeof(bmp_header), fptr_src_image) != sizeof(bmp_header))
    {
        return e_failure;
    }

    pixel_offset = (uint32_t)bmp_header[10]
                | ((uint32_t)bmp_header[11] << 8)
                | ((uint32_t)bmp_header[12] << 16)
                | ((uint32_t)bmp_header[13] << 24);

    if (pixel_offset < sizeof(bmp_header) || pixel_offset > 4096 * 1024)
    {
        return e_failure;
    }

    if (fseek(fptr_src_image, 0, SEEK_SET) != 0)
    {
        return e_failure;
    }

    remaining = (long)pixel_offset;
    while (remaining > 0)
    {
        bytes_to_copy = (size_t)((remaining > (long)sizeof(buffer)) ? sizeof(buffer) : (size_t)remaining);
        bytes_read = fread(buffer, 1, bytes_to_copy, fptr_src_image);
        if (bytes_read != bytes_to_copy)
        {
            return e_failure;
        }

        if (fwrite(buffer, 1, bytes_read, fptr_dest_image) != bytes_read)
        {
            return e_failure;
        }

        remaining -= (long)bytes_read;
    }

    return e_success;
}

Status encode_byte_to_lsb(char data, char *image_buffer)
{
    unsigned char byte_value = (unsigned char)data;
    int bit_index;

    if (image_buffer == NULL)
    {
        return e_failure;
    }

    for (bit_index = 0; bit_index < 8; bit_index++)
    {
        unsigned char bit = (unsigned char)((byte_value >> (7 - bit_index)) & 1U);
        image_buffer[bit_index] = (char)((((unsigned char)image_buffer[bit_index]) & 0xFE) | bit);
    }

    return e_success;
}

Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char image_buffer[8];
    int index;

    if (data == NULL && size > 0)
    {
        return e_failure;
    }

    if (fptr_src_image == NULL || fptr_stego_image == NULL)
    {
        return e_failure;
    }

    for (index = 0; index < size; index++)
    {
        int byte_index;

        for (byte_index = 0; byte_index < 8; byte_index++)
        {
            int ch = fgetc(fptr_src_image);
            if (ch == EOF)
            {
                return e_failure;
            }
            image_buffer[byte_index] = (char)ch;
        }

        if (encode_byte_to_lsb(data[index], image_buffer) == e_failure)
        {
            return e_failure;
        }

        if (fwrite(image_buffer, 1, sizeof(image_buffer), fptr_stego_image) != sizeof(image_buffer))
        {
            return e_failure;
        }
    }

    return e_success;
}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    unsigned char buffer[4096];
    size_t bytes_read;

    if (fptr_src == NULL || fptr_dest == NULL)
    {
        return e_failure;
    }

    while ((bytes_read = fread(buffer, 1, sizeof(buffer), fptr_src)) > 0)
    {
        if (fwrite(buffer, 1, bytes_read, fptr_dest) != bytes_read)
        {
            return e_failure;
        }
    }

    return ferror(fptr_src) ? e_failure : e_success;
}

Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    if (magic_string == NULL || encInfo == NULL)
    {
        return e_failure;
    }

    return encode_data_to_image((char *)magic_string, (int)strlen(magic_string),
                                encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    char extension[5];
    size_t ext_len;

    if (file_extn == NULL || encInfo == NULL)
    {
        return e_failure;
    }

    ext_len = strlen(file_extn);
    if (ext_len == 0 || ext_len > MAX_FILE_SUFFIX)
    {
        return e_failure;
    }

    memset(extension, 0, sizeof(extension));
    memcpy(extension, file_extn, ext_len);
    strncpy(encInfo->extn_secret_file, extension, MAX_FILE_SUFFIX);
    encInfo->extn_secret_file[MAX_FILE_SUFFIX] = '\0';

    return encode_data_to_image(encInfo->extn_secret_file, MAX_FILE_SUFFIX,
                                encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    unsigned char encoded_size[4];
    uint32_t value = (uint32_t)file_size;

    if (encInfo == NULL)
    {
        return e_failure;
    }

    encoded_size[0] = (unsigned char)((value >> 24) & 0xFFU);
    encoded_size[1] = (unsigned char)((value >> 16) & 0xFFU);
    encoded_size[2] = (unsigned char)((value >> 8) & 0xFFU);
    encoded_size[3] = (unsigned char)(value & 0xFFU);

    return encode_data_to_image((char *)encoded_size, sizeof(encoded_size),
                                encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
    unsigned char *secret_data = NULL;
    size_t data_size;
    size_t bytes_read;
    Status status = e_failure;

    if (encInfo == NULL || encInfo->fptr_secret == NULL)
    {
        return e_failure;
    }

    if (fseek(encInfo->fptr_secret, 0, SEEK_END) != 0)
    {
        return e_failure;
    }

    data_size = (size_t)ftell(encInfo->fptr_secret);
    if (data_size == (size_t)-1 || data_size == 0)
    {
        rewind(encInfo->fptr_secret);
        return e_success;
    }

    rewind(encInfo->fptr_secret);
    secret_data = (unsigned char *)malloc(data_size);
    if (secret_data == NULL)
    {
        return e_failure;
    }

    bytes_read = fread(secret_data, 1, data_size, encInfo->fptr_secret);
    if (bytes_read != data_size)
    {
        free(secret_data);
        return e_failure;
    }

    status = encode_data_to_image((char *)secret_data, (int)data_size,
                                 encInfo->fptr_src_image, encInfo->fptr_stego_image);
    free(secret_data);
    return status;
}

Status do_encoding(EncodeInfo *encInfo)
{
    const char *file_extn;

    if (encInfo == NULL)
    {
        return e_failure;
    }

    if (open_files(encInfo) == e_failure)
    {
        return e_failure;
    }

    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
    if (encInfo->image_capacity == 0)
    {
        fprintf(stderr, "Failed to determine image capacity\n");
        fclose(encInfo->fptr_stego_image);
        fclose(encInfo->fptr_secret);
        fclose(encInfo->fptr_src_image);
        return e_failure;
    }

    if (check_capacity(encInfo) == e_failure)
    {
        fclose(encInfo->fptr_stego_image);
        fclose(encInfo->fptr_secret);
        fclose(encInfo->fptr_src_image);
        return e_failure;
    }

    if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure)
    {
        fprintf(stderr, "Unable to copy BMP header\n");
        fclose(encInfo->fptr_stego_image);
        fclose(encInfo->fptr_secret);
        fclose(encInfo->fptr_src_image);
        return e_failure;
    }

    file_extn = strrchr(encInfo->secret_fname, '.');
    if (file_extn == NULL)
    {
        printf("Secret file extension missing\n");
        fclose(encInfo->fptr_stego_image);
        fclose(encInfo->fptr_secret);
        fclose(encInfo->fptr_src_image);
        return e_failure;
    }

    if (encode_magic_string(MAGIC_STRING, encInfo) == e_failure ||
        encode_secret_file_extn(file_extn, encInfo) == e_failure ||
        encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_failure ||
        encode_secret_file_data(encInfo) == e_failure ||
        copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure)
    {
        fclose(encInfo->fptr_stego_image);
        fclose(encInfo->fptr_secret);
        fclose(encInfo->fptr_src_image);
        return e_failure;
    }

    if (fclose(encInfo->fptr_stego_image) != 0)
    {
        fclose(encInfo->fptr_secret);
        fclose(encInfo->fptr_src_image);
        return e_failure;
    }
    encInfo->fptr_stego_image = NULL;

    fclose(encInfo->fptr_secret);
    encInfo->fptr_secret = NULL;
    fclose(encInfo->fptr_src_image);
    encInfo->fptr_src_image = NULL;

    printf("Encoding successful. Stego image saved as %s\n", encInfo->stego_image_fname);
    return e_success;
}
