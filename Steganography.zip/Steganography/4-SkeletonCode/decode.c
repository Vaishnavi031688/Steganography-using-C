#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "decode.h"

static Status decode_byte_from_image(FILE *image, unsigned char *decoded_byte)
{
    unsigned char image_bytes[8];
    unsigned char value = 0;

    if (fread(image_bytes, 1, sizeof(image_bytes), image) != sizeof(image_bytes))
    {
        return e_failure;
    }

    for (size_t bit = 0; bit < sizeof(image_bytes); bit++)
    {
        value = (unsigned char)((value << 1) | (image_bytes[bit] & 1U));
    }

    *decoded_byte = value;
    return e_success;
}

static Status decode_bytes_from_image(FILE *image, unsigned char *data, size_t size)
{
    for (size_t index = 0; index < size; index++)
    {
        if (decode_byte_from_image(image, &data[index]) == e_failure)
        {
            return e_failure;
        }
    }

    return e_success;
}

static Status decode_u32_from_image(FILE *image, uint32_t *value)
{
    unsigned char image_bytes[32];
    uint32_t decoded_value = 0;

    if (fread(image_bytes, 1, sizeof(image_bytes), image) != sizeof(image_bytes))
    {
        return e_failure;
    }

    for (size_t bit = 0; bit < sizeof(image_bytes); bit++)
    {
        decoded_value = (decoded_value << 1) | (image_bytes[bit] & 1U);
    }

    *value = decoded_value;
    return e_success;
}

static Status copy_stream(FILE *source, FILE *destination)
{
    unsigned char buffer[4096];
    size_t bytes_read;

    while ((bytes_read = fread(buffer, 1, sizeof(buffer), source)) > 0)
    {
        if (fwrite(buffer, 1, bytes_read, destination) != bytes_read)
        {
            return e_failure;
        }
    }

    return ferror(source) ? e_failure : e_success;
}

static char *make_default_output_name(const char *extension)
{
    static const char prefix[] = "decoded";
    size_t name_size = sizeof(prefix) - 1 + strlen(extension) + 1;
    char *name = malloc(name_size);

    if (name != NULL)
    {
        snprintf(name, name_size, "%s%s", prefix, extension);
    }

    return name;
}

Status read_and_validate_decode_args(int argc, char *argv[], DecodeInfo *decInfo)
{
    size_t image_name_length;

    if (decInfo == NULL || argv == NULL || argc < 3 || argc > 4)
    {
        fprintf(stderr, "Usage: %s -d <stego_image.bmp> [output_file]\n",
                argv != NULL && argv[0] != NULL ? argv[0] : "steganography");
        return e_failure;
    }

    image_name_length = strlen(argv[2]);
    if (image_name_length < 4 ||
        strcmp(argv[2] + image_name_length - 4, ".bmp") != 0)
    {
        fprintf(stderr, "Input image must have a .bmp extension\n");
        return e_failure;
    }

    decInfo->stego_image_fname = argv[2];
    decInfo->output_fname = argc == 4 ? argv[3] : NULL;
    decInfo->fptr_stego_image = NULL;
    decInfo->secret_file_size = 0;
    decInfo->extn_secret_file[0] = '\0';
    return e_success;
}

Status do_decoding(DecodeInfo *decInfo)
{
    unsigned char magic[sizeof(MAGIC_STRING) - 1];
    unsigned char extension[DECODE_EXTENSION_SIZE];
    unsigned char bmp_header[14];
    uint32_t pixel_offset;
    uint32_t secret_size;
    long image_size;
    long remaining_image_bytes;
    FILE *decoded_data = NULL;
    FILE *output = NULL;
    char *default_output_name = NULL;
    const char *output_name;
    Status status = e_failure;

    if (decInfo == NULL || decInfo->stego_image_fname == NULL)
    {
        fprintf(stderr, "Invalid decode information\n");
        return e_failure;
    }

    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "rb");
    if (decInfo->fptr_stego_image == NULL)
    {
        perror(decInfo->stego_image_fname);
        return e_failure;
    }

    if (fseek(decInfo->fptr_stego_image, 0, SEEK_END) != 0 ||
        (image_size = ftell(decInfo->fptr_stego_image)) < 0 ||
        fseek(decInfo->fptr_stego_image, 0, SEEK_SET) != 0 ||
        fread(bmp_header, 1, sizeof(bmp_header), decInfo->fptr_stego_image) != sizeof(bmp_header))
    {
        fprintf(stderr, "Unable to read BMP header from %s\n", decInfo->stego_image_fname);
        goto cleanup;
    }

    if (bmp_header[0] != 'B' || bmp_header[1] != 'M')
    {
        fprintf(stderr, "%s is not a BMP image\n", decInfo->stego_image_fname);
        goto cleanup;
    }

    pixel_offset = (uint32_t)bmp_header[10]
        | ((uint32_t)bmp_header[11] << 8)
        | ((uint32_t)bmp_header[12] << 16)
        | ((uint32_t)bmp_header[13] << 24);
    if (pixel_offset < sizeof(bmp_header) || pixel_offset > (uint32_t)image_size ||
        fseek(decInfo->fptr_stego_image, (long)pixel_offset, SEEK_SET) != 0)
    {
        fprintf(stderr, "Invalid BMP pixel-data offset\n");
        goto cleanup;
    }

    remaining_image_bytes = image_size - (long)pixel_offset;
    if (remaining_image_bytes < (long)(sizeof(magic) + sizeof(extension)) * 8 + 32)
    {
        fprintf(stderr, "Image is too small to contain steganographic data\n");
        goto cleanup;
    }

    if (decode_bytes_from_image(decInfo->fptr_stego_image, magic, sizeof(magic)) == e_failure ||
        memcmp(magic, MAGIC_STRING, sizeof(magic)) != 0)
    {
        fprintf(stderr, "Magic string not found; image is not recognized as encoded\n");
        goto cleanup;
    }
    remaining_image_bytes -= (long)sizeof(magic) * 8;

    if (decode_bytes_from_image(decInfo->fptr_stego_image, extension, sizeof(extension)) == e_failure)
    {
        fprintf(stderr, "Unable to decode secret file extension\n");
        goto cleanup;
    }
    remaining_image_bytes -= (long)sizeof(extension) * 8;

    if (extension[0] != '.' ||
        !isalnum(extension[1]) || !isalnum(extension[2]) || !isalnum(extension[3]))
    {
        fprintf(stderr, "Decoded file extension is invalid\n");
        goto cleanup;
    }
    memcpy(decInfo->extn_secret_file, extension, sizeof(extension));
    decInfo->extn_secret_file[DECODE_EXTENSION_SIZE] = '\0';

    if (decode_u32_from_image(decInfo->fptr_stego_image, &secret_size) == e_failure)
    {
        fprintf(stderr, "Unable to decode secret file size\n");
        goto cleanup;
    }
    remaining_image_bytes -= 32;
    if ((uint64_t)secret_size > (uint64_t)(remaining_image_bytes / 8))
    {
        fprintf(stderr, "Encoded secret file size exceeds available image data\n");
        goto cleanup;
    }

    decoded_data = tmpfile();
    if (decoded_data == NULL)
    {
        perror("tmpfile");
        goto cleanup;
    }

    for (uint32_t index = 0; index < secret_size; index++)
    {
        unsigned char decoded_byte;
        if (decode_byte_from_image(decInfo->fptr_stego_image, &decoded_byte) == e_failure ||
            fwrite(&decoded_byte, 1, 1, decoded_data) != 1)
        {
            fprintf(stderr, "Unable to decode secret file data\n");
            goto cleanup;
        }
    }
    decInfo->secret_file_size = (uint)secret_size;

    output_name = decInfo->output_fname;
    if (output_name == NULL)
    {
        default_output_name = make_default_output_name(decInfo->extn_secret_file);
        if (default_output_name == NULL)
        {
            fprintf(stderr, "Unable to allocate output filename\n");
            goto cleanup;
        }
        output_name = default_output_name;
    }

    if (fflush(decoded_data) != 0 || fseek(decoded_data, 0, SEEK_SET) != 0)
    {
        fprintf(stderr, "Unable to prepare decoded file data\n");
        goto cleanup;
    }

    output = fopen(output_name, "wb");
    if (output == NULL)
    {
        perror(output_name);
        goto cleanup;
    }
    if (copy_stream(decoded_data, output) == e_failure)
    {
        fclose(output);
        output = NULL;
        fprintf(stderr, "Unable to write decoded file %s\n", output_name);
        goto cleanup;
    }
    if (fclose(output) != 0)
    {
        output = NULL;
        fprintf(stderr, "Unable to finish writing decoded file %s\n", output_name);
        goto cleanup;
    }
    output = NULL;
    printf("Decoded secret file to %s\n", output_name);
    status = e_success;

cleanup:
    if (output != NULL)
    {
        fclose(output);
    }
    if (decoded_data != NULL)
    {
        fclose(decoded_data);
    }
    if (decInfo->fptr_stego_image != NULL)
    {
        fclose(decInfo->fptr_stego_image);
        decInfo->fptr_stego_image = NULL;
    }
    free(default_output_name);
    return status;
}
