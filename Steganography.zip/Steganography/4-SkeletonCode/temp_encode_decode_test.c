﻿#include <stdio.h>
#include "encode.h"
#include "decode.h"
int main(void) {
    char *argv[5];
    EncodeInfo encInfo = {0};
    DecodeInfo decInfo = {0};
    argv[0] = "stego";
    argv[1] = "-e";
    argv[2] = "beautiful.bmp";
    argv[3] = "secret.txt";
    argv[4] = "sample_stego.bmp";
    if (read_and_validate_encode_args(argv, &encInfo) != e_success) return 1;
    if (do_encoding(&encInfo) != e_success) return 2;
    argv[0] = "stego"; argv[1] = "-d"; argv[2] = "sample_stego.bmp"; argv[3] = "decoded_output.txt";
    if (read_and_validate_decode_args(4, argv, &decInfo) != e_success) return 3;
    if (do_decoding(&decInfo) != e_success) return 4;
    printf("DONE\n");
    return 0;
}
